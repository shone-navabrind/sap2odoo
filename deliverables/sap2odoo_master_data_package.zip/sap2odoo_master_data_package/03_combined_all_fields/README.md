# Combined All-Fields Package

One file per master data object — standard Odoo fields, every extra real SAP column, and any
line-item/child data, all merged together. This is a single-pass alternative to importing
`01_base_data/` and `02_custom_field_data/` separately: instead of loading each object twice
(once for standard fields, once as an update for custom fields), a team that wants everything
in one file per object at once can import straight from here.

## What's different from folders 1 and 2

- Same 21 numbered master objects as `01_base_data/`/`02_custom_field_data/`, but **3 of them
  are child/line-item objects that don't get their own file here** — they're folded into their
  parent's file as Odoo one2many columns instead. That leaves **18 files**:
  - `11_res_partner_bank.csv` is folded into `10_res_partner.csv` as `bank_ids/...` columns.
  - `12_res_partner_contact.csv` is folded into `10_res_partner.csv` as `child_ids/...` columns.
  - `18_product_supplierinfo.csv` is folded into `17_product_template.csv` as `seller_ids/...`
    columns.
- `19_product_pricelist_with_items.csv` and `20_mrp_bom_with_lines.csv` already merge their own
  line items (`item_ids/...` / `bom_line_ids/...`) the same way — each file is identical in
  shape to `01_base_data/`'s same-numbered file, just with the extra SAP columns (`x_...` on the
  header row, `item_ids/x_...` or `bom_line_ids/x_...` on each line row) added.
- Every extra SAP column (the same ones listed per-object in `ALL_CUSTOM_FIELDS_CHECKLIST.csv`)
  is prefixed `x_<original_full_column_name>` on a parent's own row, and `<o2m_field>/x_...` on
  a child line's row (e.g. `bank_ids/x_sap__khhousebankaccount__...`).

## One2many merge convention

Same pattern as `01_base_data/`'s pricelist file: a parent's own columns (`id`, standard fields,
`x_*` extras) are populated only on the FIRST row for that record. Every further child line is
a follow-up row with the parent columns left blank — Odoo groups any number of consecutive
blank-`id` rows under the parent row directly above them. For `10_res_partner.csv`, a partner
can have both bank lines (`bank_ids/*`) and contact lines (`child_ids/*`); each child row only
fills in the columns for whichever one2many field that line belongs to, leaving the other
one2many's columns blank on that row. No bank account or contact row is ever dropped — every
real child record appears somewhere in the file, verified by row-count reconciliation against
the source files at build time.

## Before importing

You still need to create the custom fields listed in `ALL_CUSTOM_FIELDS_CHECKLIST.csv` first,
exactly as for `02_custom_field_data/` — any file here with `x_*` columns will fail to import
those columns (though the standard fields will still work) until the matching custom fields
exist on the target model in Odoo.
