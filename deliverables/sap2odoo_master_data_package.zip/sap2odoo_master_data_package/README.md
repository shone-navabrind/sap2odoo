# SAP → Odoo Master Data Import Package

Generated from the sap2odoo pipeline against the live ByDesign tenant. Three folders: the first
two (`01_base_data/` + `02_custom_field_data/`) are a two-pass import per file, in numeric
order; the third (`03_combined_all_fields/`) is a one-pass alternative — see below.

## Folder 1 — `01_base_data/` (import FIRST, in numeric order 01 → 21)

Standard Odoo fields only — no custom fields required. These are ready to import as-is via
Odoo's Import tool (Settings → Technical → Import, or the model's own list view → Favorites →
Import Records). Each file's `id` column is an external ID; relation columns use Odoo's
`field/id` syntax (e.g. `partner_id/id`, `bank_id/id`) so Odoo resolves the links automatically
as long as files are imported in this order (a file only references external IDs from a
lower-numbered file).

| # | File | Odoo model | Mandatory? |
|---|---|---|---|
| 01 | account_analytic_plan.csv | account.analytic.plan | infrastructure (needed by 08/09) |
| 02 | uom_uom.csv | uom.uom | Yes |
| 03 | res_bank.csv | res.bank | Yes |
| 04 | product_category.csv | product.category | Yes |
| 05 | account_account.csv | account.account | Yes |
| 06 | account_tax.csv | account.tax | Yes |
| 07 | account_payment_term.csv | account.payment.term | Yes |
| 08 | account_analytic_account_cc.csv | account.analytic.account | Optional (Cost Centers) |
| 09 | account_analytic_account.csv | account.analytic.account | Optional (Analytic Accounts) |
| 10 | res_partner.csv | res.partner | Yes (Customers + Vendors) |
| 11 | res_partner_bank.csv | res.partner.bank | Optional |
| 12 | res_partner_contact.csv | res.partner | Optional |
| 13 | res_users.csv | res.users | Yes (Salespersons) |
| 14 | stock_warehouse.csv | stock.warehouse | Yes |
| 15 | stock_location.csv | stock.location | Yes |
| 16 | mrp_workcenter.csv | mrp.workcenter | Yes |
| 17 | product_template.csv | product.template | Yes |
| 18 | product_supplierinfo.csv | product.supplierinfo | Optional |
| 19 | product_pricelist_with_items.csv | product.pricelist (+ product.pricelist.item lines) | Yes |
| 20 | mrp_bom_with_lines.csv | mrp.bom (+ mrp.bom.line lines) | Yes |
| 21 | maintenance_equipment.csv | maintenance.equipment | Yes |

### About file 19 — pricelist with line items in one file

This file holds BOTH the pricelist headers and their product/price line items in a single CSV,
using Odoo's standard one2many import convention: a pricelist's first row carries its own
`id`/`name`/`currency_id/id` plus its first line item's `item_ids/...` columns; every further
line item for that same pricelist is a follow-up row with `id`/`name`/`currency_id/id` left
blank, so Odoo groups it under the pricelist directly above it. Import this file as one pass —
do not split header rows and item rows into separate imports.

Real product/price line items are attached to the pricelist an SAP sales order actually used —
resolved via Customer + Sales Organisation + Distribution Channel (the same business key SAP
itself uses internally), since SAP does not expose a direct pricelist-to-order link over OData
on this tenant. **61 of the 226 pricelists carry real product/price lines this way** (1,109
lines total, derived from `khsalesorder`'s "List Price" price component — most frequently quoted
value per product where a product appears at more than one price under the same pricelist). The
remaining 165 pricelists have no line items — SAP has no order history against them on this
tenant. A small fallback pricelist, **"SAP List Prices - Unmatched Sales Arrangement"**
(`sap_pricelist_list_prices`), holds the 8 price lines (out of 4,308 orders, ~0.2%) whose order
could not be resolved to a specific arrangement, so no real price data is silently dropped.

### About file 20 — bills of material with component lines in one file

Same one2many shape as file 19: a BOM header's first row carries `id`/`product_tmpl_id/id`/
`product_qty`/`code`/`type` plus its first component's `bom_line_ids/...` columns; every further
component for that same BOM is a follow-up row with the header columns left blank. Sourced from
`khbomvariant`, a custom OData service built directly through SAP's OData Editor (self-service,
no `.xml` import) — see `sap_odata_editor_walkthrough/bom_service_setup/README.md` for the full
build story. **400 BOM headers, 448 product variants (each variant is its own `mrp.bom` row —
one header can produce more than one output product), 14,948 component lines.** Components are
recorded against the BOM header, not per-variant, so where a header has more than one variant
(48 of the 400), every variant of that header repeats the same component list — this is a real
limit of what the tenant's data supports, not something this package guesses around.

### About file 21 — Equipment (Equipment Resources)

Sourced from `khequipmentresource`, another custom OData service built directly through SAP's
OData Editor (like file 20). **18 real equipment resources** (SMT lines, wave soldering, final
inspection, etc. — genuinely typed "Equipment Resource" in the live ByDesign UI under "Supply
Chain Design Master Data" → "Resources"). Only `name` and `serial_no` are populated in this base
file — this entity has no other fields Odoo's `maintenance.equipment` has a standard home for;
folder 2/3's extra SAP columns carry category, financial/scheduling/supply-planning relevance
indicators, and the working-day calendar code.

## Folder 2 — `02_custom_field_data/` (import SECOND, same numeric order, same files/models)

Same rows as folder 1, but with every additional real SAP column attached — fields Odoo has no
standard home for. **Before importing a file from this folder, create its custom fields in Odoo
first** (Settings → Technical → Fields, or Studio), using `ALL_CUSTOM_FIELDS_CHECKLIST.csv` as
the exact list: one row per field, with the suggested technical name (`x_sap_...`), inferred
type (Char/Float/Date/Datetime/Boolean), and which file/model it belongs to. Tick the checklist's
last column off as each field is created.

Once the custom fields for a given model exist, import that model's file from this folder as an
**update** (matched on the same `id` external ID already loaded from folder 1) — this adds the
extra columns onto the already-imported records rather than creating duplicates.

Note: files 19 and 20 in this folder are the same combined header+item_ids / header+bom_line_ids
shape as folder 1's files 19/20, but with the extra SAP columns attached (`x_...` on the header
row, `item_ids/x_...` or `bom_line_ids/x_...` on each line row). Import folder 1's file first,
then this one as an update, same as every other file.

## Folder 3 — `03_combined_all_fields/` (one-pass alternative to folders 1 + 2)

Same 21 master objects, but merged into **18 files** — standard fields, every extra SAP column,
and any child/line-item data (bank accounts, contacts, vendor pricelists, pricelist items, BOM
components) all in one file per object, using the same one2many convention as files 19/20 above.
Use this folder
instead of 01+02 when you'd rather import each object once instead of twice. It still requires
creating the same custom fields from `ALL_CUSTOM_FIELDS_CHECKLIST.csv` first — any file with
`x_*` columns needs those fields to exist before those columns will import. See that folder's
own `README.md` for exactly which child objects got folded into which parent and why.

## Notes

- `id` columns always start with `sap_` — that's how Odoo/this package tells its own rows apart
  from Odoo's built-in demo/seed data (e.g. `base.us`, `product_uom_categ_unit`).
- Countries use `base.<lowercase-iso2>` external IDs (Odoo's own built-in country records).
- If an import fails on a missing relation, it almost always means a lower-numbered file wasn't
  imported yet, or wasn't imported completely — re-check the order above.
- This package reflects the tenant's live state as of the date it was generated. In particular,
  Warehouses/Locations currently reflect a single active site on the tenant (a real, recent
  change on the SAP side, not a data-quality issue in this package).
